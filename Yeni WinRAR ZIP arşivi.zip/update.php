<?php
session_start();
include 'config.php';

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $current_time = time();
    $sql = "UPDATE users SET last_activity = '$current_time' WHERE id = '$user_id'";
    $conn->query($sql);
}

$conn->close();
?>
