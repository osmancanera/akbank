<?php
include 'config.php';

$current_time = time();
$timeout_duration = 5;


$sql = "SELECT id, last_activity FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $last_activity = $row['last_activity'];
        $status = ($current_time - $last_activity > $timeout_duration) ? 'offline' : 'online';

        $update_sql = "UPDATE users SET status = '$status' WHERE id = '" . $row['id'] . "'";
        $conn->query($update_sql);
    }
}

$conn->close();
?>
