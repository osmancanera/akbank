<?php
session_start();

if(isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true){
    header("location: index.php");
    exit;
}

$login_err = isset($_GET['error']) ? $_GET['error'] : '';
?>

<!DOCTYPE html>
<html lang="en" class="dark-style layout-wide  customizer-hide" dir="ltr" data-theme="theme-default" data-assets-path="assets/" data-template="vertical-menu-template-dark" data-style="-dark">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
    <title>Console 2024</title>
    <meta name="description" content="Start your development with a Dashboard for Bootstrap 5" />
    <meta name="keywords" content="">
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&amp;ampdisplay=swap" rel="stylesheet">
    <!-- Icons -->
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome.css" />
    <link rel="stylesheet" href="assets/vendor/fonts/tabler-icons.css" />
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icons.css" />
    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/rtl/core-dark.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/rtl/theme-default-dark.css" class="template-customizer-theme-css" />
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="assets/css/demo.css" />
    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/node-waves/node-waves.css" />
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="stylesheet" href="assets/vendor/libs/typeahead-js/typeahead.css" />
    <!-- Vendor -->
    <link rel="stylesheet" href="assets/vendor/libs/%40form-validation/form-validation.css" />
    <!-- Page CSS -->
    <!-- Page -->
    <link rel="stylesheet" href="assets/vendor/css/pages/page-auth.css">
    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>
    <script src="assets/vendor/js/template-customizer.js"></script>
    <script src="assets/js/config.js"></script>
    <style>
        .spinner-border {
            display: none;
        }
    </style>
  </head>
  <body>
    <div class="container-xxl">
      <div class="authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner py-6">
          <!-- Login -->
          <div class="card">
            <div class="card-body">
              <!-- Logo -->
              <div class="app-brand justify-content-center mb-6">
                <a href="index.html" class="app-brand-link">
                  <span class="app-brand-logo demo">
                    <svg  xmlns="http://www.w3.org/2000/svg"  width="64"  height="64"  viewBox="0 0 24 24"  fill="none"  stroke="white"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-terminal">
                      <path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 7l5 5l-5 5" /><path d="M12 19l7 0" />
                    </svg>
                  </span>
                  <span class="text-white">Console</span>
                </a>
              </div>
              <!-- /Logo -->
              <div class="alert alert-danger" role="alert" id="login-error" style="display: none;"></div>
              <form id="formAuthentication" class="mb-4">
                  <div class="mb-6">
                      <label for="email" class="form-label">Kullanıcı veya E-mail</label>
                      <input type="text" class="form-control" id="email" name="email-username" placeholder="Lütfen kullanıcı adı veya mail giriniz" autofocus>
                  </div>
                  <div class="mb-6 form-password-toggle">
                      <label class="form-label" for="password">Şifre</label>
                      <div class="input-group input-group-merge">
                          <input type="password" id="password" class="form-control" name="password" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" aria-describedby="password" />
                          <span class="input-group-text cursor-pointer">
                              <i class="ti ti-eye-off"></i>
                          </span>
                      </div>
                  </div>
                  <div class="my-8">
                      <div class="d-flex justify-content-between">
                          <div class="form-check mb-0 ms-2">
                              <input class="form-check-input" type="checkbox" id="remember-me">
                              <label class="form-check-label" for="remember-me"> Beni hatırla </label>
                          </div>
                      </div>
                  </div>
                  <div class="mb-6">
                      <button class="btn btn-primary d-grid w-100" type="button" id="login-button">
                          Giriş yap
                          <span class="spinner-border spinner-border-md" role="status" aria-hidden="true"></span>
                      </button>
                  </div>
              </form>
            </div>
          </div>
          <!-- /Register -->
        </div>
      </div>
    </div>
    <!-- build:js assets/vendor/js/core.js -->
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/node-waves/node-waves.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="assets/vendor/libs/hammer/hammer.js"></script>
    <script src="assets/vendor/libs/i18n/i18n.js"></script>
    <script src="assets/vendor/libs/typeahead-js/typeahead.js"></script>
    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->
    <!-- Vendors JS -->
    <script src="assets/vendor/libs/%40form-validation/popular.js"></script>
    <script src="assets/vendor/libs/%40form-validation/bootstrap5.js"></script>
    <script src="assets/vendor/libs/%40form-validation/auto-focus.js"></script>
    <!-- Main JS -->
    <script src="assets/js/main.js"></script>
    <!-- Page JS -->
    <script src="assets/js/pages-auth.js"></script>

    <script>
    $(document).ready(function() {
        if (localStorage.getItem('remember') === 'true') {
            $('#email').val(localStorage.getItem('email-username'));
            $('#password').val(localStorage.getItem('password'));
            $('#remember-me').prop('checked', true);
        }

        $('#login-button').click(function() {
            var emailUsername = $('#email').val();
            var password = $('#password').val();
            var rememberMe = $('#remember-me').prop('checked');

            if (emailUsername.length < 4) {
                $('#login-error').text('Kullanıcı adı en az 4 karakter olmalıdır.').show();
                return;
            }

            if (password.length < 6) {
                $('#login-error').text('Şifre en az 6 karakter olmalıdır.').show();
                return;
            }

            var $button = $(this);
            $button.prop('disabled', true);
            $button.find('.spinner-border').show();
            $button.contents().filter(function() {
                return this.nodeType === 3; // Only text nodes
            }).remove();

            $.ajax({
                url: 'post/login.php',
                type: 'POST',
                data: {
                    'email-username': emailUsername,
                    'password': password,
                    'remember-me': rememberMe
                },
                success: function(response) {
                    setTimeout(function() {
                        if(response === 'success') {
                            if (rememberMe) {
                                localStorage.setItem('email-username', emailUsername);
                                localStorage.setItem('password', password);
                                localStorage.setItem('remember', true);
                            } else {
                                localStorage.removeItem('email-username');
                                localStorage.removeItem('password');
                                localStorage.removeItem('remember');
                            }
                            window.location.href = 'index.php';
                        } else {
                            $('#login-error').text(response).show();
                            $button.prop('disabled', false);
                            $button.append(' Giriş yap');
                            $button.find('.spinner-border').hide();
                        }
                    }, 3000); // 3 saniye bekletme süresi
                }
            });
        });
    });
</script>


  </body>
</html>