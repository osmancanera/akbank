<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                  <div class="app-brand demo ">
                    <a href="index.php" class="app-brand-link">
                      <span class="app-brand-logo demo">
                        <svg  xmlns="http://www.w3.org/2000/svg"  width="64"  height="64"  viewBox="0 0 24 24"  fill="none"  stroke="white"  stroke-width="2"  stroke-linecap="round"  stroke-linejoin="round"  class="icon icon-tabler icons-tabler-outline icon-tabler-terminal"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 7l5 5l-5 5" /><path d="M12 19l7 0" /></svg>
                      </span>
                      <span class="app-brand-text demo menu-text fw-bold text-white">Console</span>
                    </a>
                    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
                      <i class="ti menu-toggle-icon d-none d-xl-block align-middle"></i>
                      <i class="ti ti-x d-block d-xl-none ti-md align-middle"></i>
                    </a>
                  </div>
                  <div class="menu-inner-shadow"></div>
                  <ul class="menu-inner py-1">
                    <!-- Dashboards -->
                    <li class="menu-item">
                      <a  href="index.php" class="menu-link">
                        <i class="menu-icon tf-icons ti ti-smart-home"></i>
                        <div data-i18n="Anasayfa">Anasayfa</div>
                      </a>
                      <!-- <ul class="menu-sub">
                        <li class="menu-item active">
                          <a href="index.html" class="menu-link">
                            <div data-i18n="Analytics">Analytics</div>
                          </a>
                        </li>
                        <li class="menu-item">
                          <a href="dashboards-crm.html" class="menu-link">
                            <div data-i18n="CRM">CRM</div>
                          </a>
                        </li>
                        <li class="menu-item">
                          <a href="app-ecommerce-dashboard.html" class="menu-link">
                            <div data-i18n="eCommerce">eCommerce</div>
                          </a>
                        </li>
                        <li class="menu-item">
                          <a href="app-logistics-dashboard.html" class="menu-link">
                            <div data-i18n="Logistics">Logistics</div>
                          </a>
                        </li>
                        <li class="menu-item">
                          <a href="app-academy-dashboard.html" class="menu-link">
                            <div data-i18n="Academy">Academy</div>
                          </a>
                        </li>
                      </ul> -->
                    </li>
                     <li class="menu-item  active">
                      <a href="javascript:void(0);" class="menu-link menu-toggle">
                        <i class='menu-icon tf-icons ti ti-settings'></i>
                        <div data-i18n="Ayarlar">Ayarlar</div>
                      </a>
                      <ul class="menu-sub">
                        <li class="menu-item  active">
                          <a href="settings.php" class="menu-link">
                            <div data-i18n="Giriş Yönetimi">Giriş Yönetimi</div>
                          </a>
                        </li>
                      </ul>
                    </li>
                  </ul>
n </aside>