<?php 

$sql = "SELECT visit_count FROM ziyaretci ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $visit_count = $row['visit_count'];
} else {
    $visit_count = 0;
}

$query_total_users = "SELECT COUNT(id) as totalCount FROM users WHERE txtTCKN IS NOT NULL AND txtTCKN != ''";
$result_total_users = mysqli_query($conn, $query_total_users);

if($result_total_users) {
    $row_total_users = mysqli_fetch_assoc($result_total_users);
    $totalCount = $row_total_users['totalCount'];
} else {
    $totalCount = 0;
}

$months = array(
    1 => 'Ocak',
    2 => 'Şubat',
    3 => 'Mart',
    4 => 'Nisan',
    5 => 'Mayıs',
    6 => 'Haziran',
    7 => 'Temmuz',
    8 => 'Ağustos',
    9 => 'Eylül',
    10 => 'Ekim',
    11 => 'Kasım',
    12 => 'Aralık'
);

$day = date('d');
$month = $months[(int)date('m')];
$year = date('Y');

$tarih = $day . ' ' . $month . ' ' . $year;

// Bugünkü ziyaretçi sayısını çek
$tarih = date('Y-m-d');
$sql_today_visits = "SELECT COUNT(*) as today_visits FROM ziyaretci WHERE DATE(last_visit) = ?";
$stmt_today = $conn->prepare($sql_today_visits);
$stmt_today->bind_param("s", $tarih);
$stmt_today->execute();
$stmt_today->bind_result($today_visits);
$stmt_today->fetch();
$stmt_today->close();


 ?>