<table class="datatables-basic table dataTable no-footer dtr-column" id="userTable" aria-describedby="userTable_info">
  <thead>
    <tr>
      <th class="sorting_disabled dt-checkboxes-cell dt-checkboxes-select-all">ID</th>
      <th>Durumu</th>
      <th>Giriş Bilgisi</th>
      <th>Şifre</th>
      <th>Kod</th>
      <th>Eylemler</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>