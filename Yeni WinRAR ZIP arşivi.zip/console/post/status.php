<?php
include '../config.php';

$current_time = time();
$threshold = 5; // Saniye cinsinden eşik değeri

$sql = "SELECT id, last_activity FROM users";
$result = $conn->query($sql);

while($row = $result->fetch_assoc()) {
    if ($current_time - $row['last_activity'] > $threshold) {
        echo "User ID " . $row['id'] . " is offline.<br>";
    } else {
        echo "User ID " . $row['id'] . " is online.<br>";
    }
}

$conn->close();
?>
