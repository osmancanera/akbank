<?php
include '../config.php';

// Hata raporlamayı devre dışı bırak
error_reporting(0);
ini_set('display_errors', 0);

// Şu anki zaman
$current_time = time();
$timeout_duration = 5; // 5 saniye

$response = array();

try {
    // Kullanıcıların durumunu kontrol et
    $sql = "SELECT id, last_activity FROM users";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $last_activity = $row['last_activity'];
            $status = ($current_time - $last_activity > $timeout_duration) ? 'offline' : 'online';

            // Durumu güncelle
            $update_sql = "UPDATE users SET status = ? WHERE id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("si", $status, $row['id']);
            $stmt->execute();
        }
        $response['status'] = 'success';
        $response['message'] = 'Statuses updated successfully';
    } else {
        $response['status'] = 'error';
        $response['message'] = 'No users found';
    }

    if ($stmt) {
        $stmt->close();
    }
    $conn->close();
} catch (Exception $e) {
    $response['status'] = 'error';
    $response['message'] = $e->getMessage();
}

// JSON yanıtı döndür
header('Content-Type: application/json');
echo json_encode($response);
?>
