<?php
require_once "../config.php";

session_start();

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $usernameOrEmail = trim($_POST["email-username"]);
    $password = trim($_POST["password"]);

    $sql = "SELECT id, username, password FROM admins WHERE username = ? OR email = ?";
    
    if($stmt = mysqli_prepare($conn, $sql)){
        mysqli_stmt_bind_param($stmt, "ss", $param_usernameOrEmail, $param_usernameOrEmail);
        $param_usernameOrEmail = $usernameOrEmail;
        
        if(mysqli_stmt_execute($stmt)){
            mysqli_stmt_store_result($stmt);
            
            if(mysqli_stmt_num_rows($stmt) == 1){                    
                mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                if(mysqli_stmt_fetch($stmt)){
                    if(password_verify($password, $hashed_password)){
                        $_SESSION["admin_logged_in"] = true;
                        $_SESSION["id"] = $id;
                        $_SESSION["username"] = $username;

                        echo 'success';
                    } else{
                        echo 'Parola yanlış.';
                    }
                }
            } else{
                echo 'Kullanıcı adı veya e-posta bulunamadı.';
            }
        } else{
            echo 'Bir şeyler ters gitti. Lütfen tekrar deneyin.';
        }

        mysqli_stmt_close($stmt);
    }
}

mysqli_close($conn);
?>
