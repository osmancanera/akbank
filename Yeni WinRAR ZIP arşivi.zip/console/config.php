<?php
// Veritabanı bağlantı bilgileri
define('DB_SERVER', 'localhost'); // Veritabanı sunucusu
define('DB_USERNAME', 'root'); // Veritabanı kullanıcı adı
define('DB_PASSWORD', ''); // Veritabanı parolası
define('DB_NAME', 'akbank'); // Veritabanı adı


$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

if($conn === false){
    die("ERROR: Veritabanı bağlantısı başarısız: " . mysqli_connect_error());
}

// Genel ayarlar
define('BASE_URL', 'http://localhost/proje_adi'); 
define('SITE_NAME', 'Admin Paneli');

?>
