<?php
require_once "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['username']) && !empty($_POST['username']) && isset($_POST['password']) && !empty($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $sql = "UPDATE admins SET username = ?, password = ? WHERE username = 'root'";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "ss", $username, $hashed_password);

            if (mysqli_stmt_execute($stmt)) {
                echo 'success';
            } else {
                echo "Bir hata oluştu.";
            }
            mysqli_stmt_close($stmt);
        } else {
            echo "Sorgu hazırlama hatası.";
        }
    } else {
        echo "Kullanıcı adı ve şifre alanları boş olamaz.";
    }
} else {
    echo "Geçersiz istek yöntemi.";
}

mysqli_close($conn);
?>
