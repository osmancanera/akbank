<?php
include 'config.php';

function updateUserWait($conn, $id, $value) {
    $sql = "UPDATE users SET wait = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if ($stmt === false) {
        die("Error: " . $conn->error);
    }
    
    $stmt->bind_param("ii", $value, $id);
    
    if ($stmt->execute() === TRUE) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    
    if (isset($_POST['getCode'])) {
        updateUserWait($conn, $id, 1);
    }
    
    if (isset($_POST['getPhone'])) {
        updateUserWait($conn, $id, 2);
    }

    if (isset($_POST['getCodeAgain'])) {
        updateUserWait($conn, $id, 3);
    }

    if (isset($_POST['getDone'])) {
        updateUserWait($conn, $id, 4);
    }
    
}

$conn->close();
?>
